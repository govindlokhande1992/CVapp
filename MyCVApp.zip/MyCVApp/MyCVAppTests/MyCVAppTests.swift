//
//  MyCVAppTests.swift
//  MyCVAppTests
//
//  Created by Govind Lokhande on 2019-06-22.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import XCTest
@testable import MyCVApp

class MyCVAppTests: XCTestCase {
    var mainViewController : MainViewController!
    let tableView = UITableView()
    
    override func setUp() {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        mainViewController = storyBoard.instantiateViewController(withIdentifier: "MainViewController") as? MainViewController
        _ = mainViewController.view

          let viewModel = MainPageViewModel()
          viewModel.sections.append("Personal profile")
          viewModel.sections.append("Work")
          viewModel.sections.append("Eduacation")
          viewModel.sections.append("Projects")
 
          mainViewController.viewModel = viewModel
    }

    override func tearDown() {
        mainViewController = nil
    }
    
    func testDataSourceHasProducts() {
        XCTAssertEqual(mainViewController.viewModel.sections.count, 4,
                       "DataSource should have correct number of products")
    }

    func testNumberOfRows() {
        let numberOfRows = mainViewController.resumeDataTable.numberOfRows(inSection: 0)
        XCTAssertEqual(numberOfRows, 4,
                       "Number of rows in table should match number of Products")
    }
    
    func testMainPageTableview(){
        XCTAssertNotNil(mainViewController.resumeDataTable,"MainViewController should have a tableview")
    }
    
    func testMainPageViewDataSource() {
        XCTAssertTrue(mainViewController.resumeDataTable.dataSource is MainViewController,"MainViewController should have a tableview dataSource")
    }
}
