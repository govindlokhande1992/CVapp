//
//  APIServicesTests.swift
//  MyCVAppTests
//
//  Created by Govind Lokhande on 2019-06-22.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import XCTest
@testable import MyCVApp

class APIServicesTests: XCTestCase {
     var sut: APIservices?
    let decoder = JSONDecoder()


    override func setUp() {
        sut = APIservices()
    }

    override func tearDown() {
        sut = nil
        super.tearDown()
        
    }
    
    func testgetResumData() {
        let service = APIservices()
        let mockURLSession  = MockURLSession()
        service.fetchResumedata{ (resumeData , error)   in }
        service.session = mockURLSession
    
    }
    
    func testInvokeResumedata() {
         let sut = self.sut
         let expect = XCTestExpectation(description: "callback")
        if(sut?.baseURL != nil){
            sut?.fetchResumedata{ (resumeData , error)  in
                expect.fulfill()
            }
            wait(for: [expect], timeout: 3.1)
            
        }else{
            XCTAssert(false, "Fetch resume data URL is not present....")
        }
    }
    
    func testValidCallTofetchResumeData() {
        // given
        let sut = self.sut
        sut?.session = URLSession()
        let url = URL(string: "https://govindlokhande1992.github.io/JsonHolder/data.json")
        // 1
        let promise = expectation(description: "Status code: 200")
        
        let dataTask = sut?.session.dataTask(with: url!) { (data,response,error) in
            if let error = error {
                XCTFail("Error: \(error.localizedDescription)")
                return
            } else {
                do {
                    let resumeResponse = try? self.decoder.decode(Resume.self, from: data!) as Resume
                    XCTAssertEqual(resumeResponse?.sections.count, 5, "Didn't parse 5 items from fake response")
                } catch  {
                    XCTFail("Error: \(error.localizedDescription)")
                }
            }
        }
        dataTask?.resume()
        // 3
        wait(for: [promise], timeout: 5)
    }
}

class MockURLSession: URLSession {
    var cachedUrl: URL?
    override func dataTask(with url: URL, completionHandler:      @escaping(Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask {
        self.cachedUrl = url
        return URLSessionDataTask()
    }
}
