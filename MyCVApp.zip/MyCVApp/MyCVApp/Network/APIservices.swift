//
//  APIservices.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-20.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import Foundation

typealias JSONTaskCompletionHandler = (Resume?, APIError?) -> Void

//Enum to handle the network error's
enum APIError: Error {
    case requestFailed
    case jsonConversionFailure
    case invalidData
    case invalidURL
    case jsonParsingFailure
    case requestExcutedsuccessfully
    var localizedDescription: String {
        switch self {
        case .requestFailed: return "Request Failed"
        case .invalidData: return "Invalid URL"
        case .invalidURL: return "Invalid URL"
        case .jsonParsingFailure: return "JSON Parsing Failure"
        case .jsonConversionFailure: return "JSON Conversion Failure"
        case .requestExcutedsuccessfully: return "Successfull"
        }
    }
}

public enum HTTPMethod: String {
    case get = "GET"
    case post = "POST"
    case put = "PUT"
    case delete = "DELETE"
    case patch = "PATCH"
}

class APIservices {
    let baseURL = "https://govindlokhande1992.github.io/JsonHolder/data.json"
    let decoder = JSONDecoder()
    var session: URLSession!

    
    //Function to prepaire the HTTP request....
    func getRequest<T : Encodable>(method : String, api : URL, dataObject : T) -> URLRequest {
        var request = URLRequest(url:  api)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        return request
    }
    
    func fetchResumedata(completion: @escaping JSONTaskCompletionHandler){

        guard let url = URL(string: baseURL) else {
            completion(nil, .invalidURL)
            return
        }

        let request = getRequest(method:HTTPMethod.get.rawValue, api:url, dataObject: "")
        session = URLSession.shared
        let task = session.dataTask(with: request) { (data,response,error) in
            guard let data = data else {
                completion(nil, .requestFailed)
                return
            }
            do {
                let resumeResponse = try? self.decoder.decode(Resume.self, from: data) as Resume
                completion(resumeResponse, nil)
            } catch let error as NSError {
                completion(nil, .jsonParsingFailure)
            }
        }
        task.resume()
    }

}


//Invest

