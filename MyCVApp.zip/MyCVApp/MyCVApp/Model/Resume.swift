//
//  Resume.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-20.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import Foundation
// MARK: - Education
struct Education: Codable {
    let location, area, endDate, institution: String
    let studyType, startDate: String
}

// MARK: - Info
struct Info: Codable {
    let name, email, phone, website: String
    let address: String
    let image: String
}

// MARK: - Project
struct Project: Codable {
    let keywords: [String]
    let name, projectDescription: String
    let url: String
    
    enum CodingKeys: String, CodingKey {
        case keywords, name
        case projectDescription = "description"
        case url
    }
}

// MARK: - Skills
struct Skills: Codable {
    let languages, tools, os: String
    
    enum CodingKeys: String, CodingKey {
        case languages = "Languages"
        case tools = "Tools"
        case os = "OS"
    }
}

// MARK: - Work
struct Work: Codable {
    let location: String
    let website: String?
    let highlights: [String]
    let startDate, company, position, endDate: String
}

struct Resume: Codable {
    let info: Info
    let education: [Education]
    let work: [Work]
    let skills: Skills
    let projects: [Project]
    let sections: [String]
}
