//
//  DetailedViewController.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-20.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import UIKit

class DetailedViewController: UIViewController, Storyboard{
    var viewModel:DetailedPageViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = viewModel?.title.capitalizingFirstLetter()
        print(viewModel?.resumeModel)
    }

}
