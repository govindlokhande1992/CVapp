//
//  MainViewController.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-20.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import UIKit

class MainViewController: UIViewController, Storyboard {
    
    lazy var viewModel: MainPageViewModel = {
        return MainPageViewModel()
    }()
    
    let cellIdentifer = "SectioTableViewCell"
    let profileCellIdentifier = "ProfileTableViewCell"
    var delegate:failureCallback?
    var coordinator : gotoDetailviewProtocol?
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var resumeDataTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = viewModel.title
        loadData()
        
    }
    func loadData(){
        self.resumeDataTable.register(UINib(nibName: cellIdentifer, bundle: nil), forCellReuseIdentifier: cellIdentifer)
        self.resumeDataTable.register(UINib(nibName: profileCellIdentifier
            , bundle: nil), forCellReuseIdentifier: profileCellIdentifier)
        self.resumeDataTable.isHidden = true
        self.resumeDataTable.separatorColor = UIColor.clear
        self.activityIndicator.startAnimating()
        loadResumeData()
    }

    func loadResumeData(){
        //Check internet connectivity before executing the api call......
        viewModel.loadResumeData {[weak self] (isExecute, error) in
            if(isExecute){
                //stop rotating spinner
                self?.activityIndicator.stopAnimating()
                self?.activityIndicator.isHidden = true
                self?.resumeDataTable.isHidden = false
                self?.resumeDataTable.reloadData()
                
            }else{
                /**** This code should be execute if error is nil */
                //Don't reload the table and show error message popUp.
                //stop rotating spinner
                self?.activityIndicator.stopAnimating()
                self?.activityIndicator.isHidden = true
                self?.resumeDataTable.isHidden = true
                self!.delegate?.errorAlert(inputError: error?.localizedDescription ?? "Something went wrong.")
            }
        }
    }
}

//Class extension to implement tableview data source
extension MainViewController:UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfCells
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (indexPath.row == 0){
            guard let profileData = viewModel.resumeModel else{
                return UITableViewCell()
            }
            let cell = tableView.dequeueReusableCell(withIdentifier: profileCellIdentifier, for: indexPath) as? ProfileTableViewCell
            cell?.backgroundColor = UIColor.clear
            cell?.configure(data: profileData)

            return cell!
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifer, for: indexPath) as? SectioTableViewCell
            cell?.backgroundColor = UIColor.clear
            cell?.configure(withViewModel: viewModel.getCellTitle(indexPath: indexPath))
            return cell!
        }
    }
}
//Class extension to implement tableview delegate
extension MainViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (indexPath.row == 0){
            return 250
        }else{
            return 100
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(indexPath.row != 0){
            coordinator?.gotoDetailedView(vcTogo: viewModel.resumeModel?.sections[indexPath.row] ?? "", resumeModel: viewModel.resumeModel!)
        }
    }
}
