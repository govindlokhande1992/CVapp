//
//  SectioTableViewCell.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-20.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import UIKit

class SectioTableViewCell: UITableViewCell {

    @IBOutlet weak var fieldTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    //Function to configure the data W.R.T model
    func configure(withViewModel resumeDataTitle:String){
        self.fieldTitle.text = resumeDataTitle.capitalizingFirstLetter()
    }
}
