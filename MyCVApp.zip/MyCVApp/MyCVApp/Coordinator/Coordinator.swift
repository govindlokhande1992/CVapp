//
//  Coordinator.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-20.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import Foundation

import UIKit

protocol Coordinator {
    
    var childCoordinators: [Coordinator] {get set}
    var navigationController:UINavigationController {get set}
    
    func start()
}
