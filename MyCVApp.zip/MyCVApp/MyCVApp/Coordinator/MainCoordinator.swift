//
//  MainCoordinator.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-20.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import Foundation
import UIKit

protocol failureCallback {
    func errorAlert(inputError errormsg:String)
}

protocol gotoDetailviewProtocol {
    func gotoDetailedView(vcTogo title:String, resumeModel:Resume)
}
class MainCoordinator: Coordinator {    
    var childCoordinators = [Coordinator]()
    var navigationController: UINavigationController
    
    init(navigationController:UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let mainVC = MainViewController.instantiate()
        mainVC.delegate = self
        mainVC.coordinator = self
        navigationController.pushViewController(mainVC, animated: true)
    }
}

extension MainCoordinator: failureCallback{
    func errorAlert(inputError errormsg: String) {
        let alert = UIAlertController(title: "Error", message: errormsg, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        navigationController.present(alert, animated: true, completion: nil)
    }
}

extension MainCoordinator: gotoDetailviewProtocol{
    func gotoDetailedView(vcTogo title:String, resumeModel:Resume){
        let detailedVC = DetailedViewController.instantiate()
        detailedVC.viewModel = DetailedPageViewModel(title: title, resumeModel: resumeModel)//Data passing...
        navigationController.pushViewController(detailedVC, animated: true)
    }
}
