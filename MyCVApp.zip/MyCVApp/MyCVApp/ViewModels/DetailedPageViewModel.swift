//
//  DetailedPageViewModel.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-24.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import Foundation

final class DetailedPageViewModel {
    
    var title: String
    var resumeModel:Resume?

    
    init(title:String, resumeModel:Resume) {
        self.title = title
        self.resumeModel = resumeModel
    }

}
