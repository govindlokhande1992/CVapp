//
//  MainPageViewModel.swift
//  MyCVApp
//
//  Created by Govind Lokhande on 2019-06-20.
//  Copyright © 2019 Govind Lokhande. All rights reserved.
//

import Foundation


final class MainPageViewModel {
    
    var service = APIservices()
    var resumeModel:Resume?
    var title = "Resume"
    var sections:[String?] = []
    
    func loadResumeData(completion: @escaping (Bool,APIError?)-> Void) {
        service.fetchResumedata{ (resumeData , error)   in
            DispatchQueue.main.async {
                if(error == nil){
                    self.resumeModel = resumeData
                    self.sections = resumeData?.sections ?? []
                    completion(true, error)
                }else{
                    completion(false,error)
                }
            }
        }
    }
    
    var numberOfCells: Int {
        return sections.count
    }
    
    func getCellTitle(indexPath: IndexPath)-> String {
        return self.sections[indexPath.row] ?? ""
    }
}
